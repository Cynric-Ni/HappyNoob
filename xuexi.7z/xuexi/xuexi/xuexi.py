import requests
import json
import re

url = 'https://xxt.cxfww.cn:9090/api/client/courseware/time'
header ={'Connection':'keep-alive',
'Content-Length':'25',
'sec-ch-ua': '"Google Chrome";v="105", "Not)A;Brand";v="8", "Chromium";v="105"',
'Accept':'application/json, text/plain, */*',
'User-Access-Token':'3Bos3kDFu8MF3Dk7VgE5z5IAzzgB46EfTblm',
'sec-ch-ua-mobile':'?0',
'Content-Type':'application/json;charset=UTF-8',
'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36',
'sec-ch-ua-platform': '"Windows"',
'Origin':' https://xxt.cxfww.cn:9090',
'Sec-Fetch-Site': 'same-origin',
'Sec-Fetch-Mode': 'cors',
'Sec-Fetch-Dest': 'empty',
'Referer':'https://xxt.cxfww.cn:9090/home2?count&cover&createTime=1661576289000&dataFileName=2022%2F0827%2F0603027514.mp4&dir=2&dirId=rRcHWa3ZBkrUYcZE&dirName=%E7%BD%91%E7%BB%9C%E5%AE%89%E5%85%A8%E6%84%8F%E8%AF%86%E5%9F%B9%E8%AE%AD%E8%A7%86%E9%A2%91&enable=true&id=r0c1Sq3ZBkqHPelF&length&name=7%E3%80%81%E4%B8%80%E7%BA%BF%E5%8D%95%E4%BD%8D%E8%88%86%E6%83%85%E7%AE%A1%E7%90%86&orgName&orgs&processFileName=2022%2F0827%2F0603027514%2F0603027514.m3u8&recordId=65401956&size=542895515&sourceFileName=7%E3%80%81%E4%B8%80%E7%BA%BF%E5%8D%95%E4%BD%8D%E8%88%86%E6%83%85%E7%AE%A1%E7%90%86.mp4&suffix=mp4&type=3',
'Accept-Encoding': 'gzip, deflate, br',
'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8'
}
data = {"id":"r2BKrW3ZBkoIHL2f"}
req = requests.post(url,data = json.dumps(data))
print(req.text)